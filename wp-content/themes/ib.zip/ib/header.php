<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

	<title>International Bank (Liberia) Limited</title>
	<link rel="stylesheet" id="bootstrap-css" href="<?php echo get_template_directory_uri() . '/build/css/bootstrap.css' ?>" type="text/css" media="all">
	<link rel="stylesheet" id="awesome-font-css" href="<?php echo get_template_directory_uri() . '/build/css/font-awesome.css' ?>" type="text/css" media="all">
	<link rel="stylesheet" id="ionicon-font-css" href="<?php echo get_template_directory_uri() . '/build/css/ionicon.css' ?>" type="text/css" media="all">
    <link rel="stylesheet" id="royal-preload-css" href="<?php echo get_template_directory_uri() . '/build/css/royal-preload.css' ?>" type="text/css" media="all">
	<link rel="stylesheet" id="slick-slider-css" href="<?php echo get_template_directory_uri() . '/build/css/slick.css' ?>" type="text/css" media="all">
	<link rel="stylesheet" id="slick-theme-css" href="<?php echo get_template_directory_uri() . '/build/css/slick-theme.css' ?>" type="text/css" media="all">
	<link rel="stylesheet" id="consultax-style-css" href="<?php echo get_template_directory_uri() . '/build/css/style.css' ?>" type="text/css" media="all">

    <!-- RS5.0 Main Stylesheet -->
    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri() . '/build/revolution/css/settings.css' ?>">

    <!-- RS5.0 Layers and Navigation Styles -->
    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri() . '/build/revolution/css/layers.css' ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri() . '/build/revolution/css/navigation.css' ?>">

    <link rel="shortcut icon" href="<?php echo get_template_directory_uri() . '/images/ib-favicon.png' ?>">

    <!-- IB STYLE SHEET -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" />

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;700;900&display=swap" rel="stylesheet">
    
    
    <link rel="stylesheet" href="<?php echo get_template_directory_uri() . '/build/css/ib.css' ?>" type="text/css" media="all">

    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>


    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</head>
<body class="royal_preloader">
	<div id="page" class="site">

    <header id="site-header" class="site-header mobile-header-blue header-style-1">
        <div id="header_topbar" class="header-topbar md-hidden sm-hidden clearfix">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <!-- social icons -->
                        <ul class="social-list fleft">
                            <li><a href="https://web.facebook.com/ibliberialimited/" target="_blank"><i class="fab fa-facebook"></i></a>
                            </li>
                            <li><a href="https://www.linkedin.com/company/international-bank-liberia-ltd/" target="_blank"><i class="fab fa-linkedin"></i></a>
                            </li>
                            <li><a href="https://www.instagram.com/ibliberia/" target="_blank"><i class="fab fa-instagram"></i></a>
                            </li>
                        
                        </ul>
                        <!-- social icons close -->
                        <div class="topbar-text fright"> Opening Hours : Monday to Friday - 9AM to 2PM | Saturday 9AM to 12 Noon</div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Top bar close -->
        

        <!-- Main header start -->
        <div class="ib-main-header">
            <div class="ib-main-header-wrap">
                <div class="ib-navigation">
                    <a href="<?php echo site_url() ?>" class="ib-brand-logo">
                        <img src="<?php echo get_theme_file_uri( '/images/ib-brand-logo-with-name.png' ) ?>" alt="">
                    </a>
                    <a href="<?php echo site_url( '/personal' ) ?>" class="ib-menu-link ib-personal">PERSONAL</a>
                    <a href="<?php echo site_url( '/small-business' ) ?>" class="ib-menu-link ib-small-business">SMALL BUSINESS</a>
                    <a href="<?php echo site_url( '/corporate-institutional' ) ?>" class="ib-menu-link ib-corporate-institutional">CORPORATE & INSTITUTIONAL</a>
                    <a href="<?php echo site_url( '/about' ) ?>" class="ib-menu-link ib-about">ABOUT</a>
                    <a href="<?php echo site_url( '/resources' ) ?>" class="ib-menu-link ib-resources">RESOURCES</a>
                </div>

                <a target="_blank" href="https://onlinebanking.ibliberia.com/Trustbank_InternetBanking/" class="ib-internet-banking">
                    <img src="<?php echo get_theme_file_uri( '/icons/online-banking.png' ) ?>" alt="">
                </a>
                <a target="_blank" href="https://onlinebanking.ibliberia.com/Trustbank_InternetBanking/" class="ib-internet-banking-icon">
                    <img src="<?php echo get_theme_file_uri( '/icons/online-banking-icon.png' ) ?>" alt="">
                </a>
            </div>
        </div>


        <!-- MOBILE HEADER -->
        <div class="header_mobile">
                <div class="mlogo_wrapper clearfix">
                    <div class="mobile_logo">
                        <a href="<?php echo site_url() ?>"><img src="<?php echo get_theme_file_uri( '/images/ib-brand-logo-with-name-white.png' ) ?>" alt="Consultax"></a>
                    </div>
                    <div id="mmenu_toggle">
                        <button></button>
                    </div>
                </div>
                <div class="mmenu_wrapper">
                    <div class="mobile_nav collapse">
                        <ul id="menu-main-menu" class="mobile_mainmenu">
                            <li class="current_page_item current-menu-ancestor current-menu-parent current_page_parent current_page_ancestor menu-item-has-children">
                                <a href="<?php echo site_url( '/personal' ) ?>">PERSONAL</a>
                                <ul class="sub-menu">
                                    <li class="menu-item-2016"><a href="<?php echo site_url( '/personal#ib-personal-get-an-account' ) ?>">GET AN ACCOUNT</a></li>
                                    <li class="menu-item-2015"><a href="<?php echo site_url( '/personal#ib-personal-credit-facilities' ) ?>">CREDIT FACILITIES</a></li>
                                    <li class="menu-item-2059"><a href="<?php echo site_url( '/personal#ib-e-banking' ) ?>">E-BANKING</a></li>
                                </ul>
                            </li>
                            <li class="menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1731">
                                <a href="<?php echo site_url( '/small-business' ) ?>">SMALL BUSINESS</a>
                                <ul class="sub-menu">
                                    <li class="menu-item-1738"><a href="<?php echo site_url( '/small-business#ib-small-business-get-an-account' ) ?>">GET AN ACCOUNT</a></li>
                                    <li class="menu-item-1745"><a href="<?php echo site_url( '/small-business#ib-small-business-credit-facilities' ) ?>">BUSINESS CREDIT FACILITIES</a></li>
                                    <li class="menu-item-1742"><a href="<?php echo site_url( '/small-business#ib-small-business-e-banking' ) ?>">BUSINESS E-BANKING</a></li>
                                    <li class="menu-item-1746"><a href="<?php echo site_url( '/other-services' ) ?>">OTHER SERVICES</a></li>
                                </ul>
                            </li>
                            <li class="menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1789">
                                <a href="<?php echo site_url() ?>/corporate-institutional">CORPORATE & INSTITUTIONAL</a>
                                <ul class="sub-menu">
                                    <li class="menu-item-1791"><a href="<?php echo site_url( '/corporate-institutional#ib-corporate-get-an-account' ) ?>">GET AN ACCOUNT</a></li>
                                    <li class="menu-item-1758"><a href="<?php echo site_url( '/corporate-institutional#ib-corporate-credit-facilities' ) ?>">CREDIT FACILITIES</a></li>
                                    <li class="menu-item-1790"><a href="<?php echo site_url( '/corporate-institutional#ib-e-banking' ) ?>">E-BANKING</a></li>
                                </ul>
                            </li>
                            <li class="menu-item-has-children"><a href="<?php echo site_url( '/about' ) ?>">ABOUT</a>
                                <ul class="sub-menu">
                                    <li><a href="<?php echo site_url( '/about#ib-team' ) ?>">OUR TEAM</a></li>
                                    <li><a href="<?php echo site_url( '/about#ib-partners' ) ?>">IB PARTNERS</a></li>
                                    <li><a href="<?php echo site_url( '/about#ib-community' ) ?>">IB IN THE COMMUNITY</a></li>
                                    <li><a href="<?php echo site_url( '/about#ib-location' ) ?>">IB LOCATIONS</a></li>
                                </ul>
                            </li>
                            <li class="menu-item-has-children"><a href="<?php echo site_url() ?>/resources">RESOURCES</a>
                                <ul class="sub-menu">
                                    <li><a href="<?php echo site_url( '/resources' ) ?>">ANNOUNCEMENT </a></li>
                                    <li><a href="<?php echo site_url( '/blog' ) ?>">BLOG</a></li>
                                </ul>
                            </li>
                            <li><a href="https://onlinebanking.ibliberia.com/Trustbank_InternetBanking/" target="_blank">ONLINE BANKING LOGIN</a></li>
                        </ul>
                    </div>
                </div>
            </div>









        <!-- PHP LOGIC -->
        
        <?php 
            if(strpos($_SERVER['REQUEST_URI'], 'personal') !== false ) {
                ?>
                    <style>
                        a.ib-menu-link.ib-personal {
                            background-color: #98A544;
                            color: #FFF;
                        }
                    </style>

                    <!-- sub header start -->
                    <div class="ib-sub-header">
                        <div class="ib-sub-header-wrap">
                            <div class="ib-navigation">
                                <a href="#ib-personal-get-an-account" class="ib-menu-link" id="personal-get-account">GET AN ACCOUNT</a>
                                <a href="#ib-personal-credit-facilities" class="ib-menu-link" id="personal-credit">CREDIT FACILITIES</a>
                                <a href="#ib-e-banking" class="ib-menu-link" id="personal-ebanking">E-BANKING</a>
                            </div>
                        </div>
                    </div>
                <?php
            } else if(strpos($_SERVER['REQUEST_URI'], 'small-business') !== false || strpos($_SERVER['REQUEST_URI'], 'other-services') !== false) {
                ?>
                    <style>
                        a.ib-menu-link.ib-small-business {
                            background-color: #98A544;
                            color: #FFF;
                        }
                    </style>
                    
                    <!-- sub header start -->
                    <div class="ib-sub-header">
                        <div class="ib-sub-header-wrap">
                            <div class="ib-navigation">
                                <a href="#ib-small-business-get-an-account" class="ib-menu-link" id="small-business-get-account">GET AN ACCOUNT</a>
                                <a href="#ib-small-business-credit-facilities" class="ib-menu-link" id="small-business-credit">BUSINESS CREDIT FACILITIES</a>
                                <a href="#ib-small-business-e-banking" class="ib-menu-link" id="small-business-ebanking">BUSINESS E-BANKING</a>
                                <a href="/other-services" class="ib-menu-link">OTHER SERVICES</a>
                            </div>
                        </div>
                    </div>
                <?php
            } else if(strpos($_SERVER['REQUEST_URI'], 'corporate-institutional') !== false ) {
                ?> 
                    <style>
                        a.ib-menu-link.ib-corporate-institutional {
                            background-color: #98A544;
                            color: #FFF;
                        }
                    </style>

                    <!-- sub header start -->
                    <div class="ib-sub-header">
                        <div class="ib-sub-header-wrap">
                            <div class="ib-navigation">
                                <a href="#ib-corporate-get-an-account" id="corporate-get-account" class="ib-menu-link">GET AN ACCOUNT</a>
                                <a href="#ib-corporate-credit-facilities" id="corporate-credit" class="ib-menu-link">CREDIT FACILITIES</a>
                                <a href="#ib-e-banking" id="corporate-e-banking" class="ib-menu-link">E-BANKING</a>
                            </div>
                        </div>
                    </div>
                <?php
            } else if(strpos($_SERVER['REQUEST_URI'], 'about') !== false ) {
                ?>
                    <style>
                        a.ib-menu-link.ib-about {
                            background-color: #98A544;
                            color: #FFF;
                        }
                    </style>

                    <!-- sub header start -->
                    <div class="ib-sub-header">
                        <div class="ib-sub-header-wrap">
                            <div class="ib-navigation">
                                <a href="#ib-team" class="ib-menu-link" id="ib-team-nav">Our Team</a>
                                <a href="#ib-partners" class="ib-menu-link" id="ib-partners-nav">IB Partners</a>
                                <a href="#ib-community" class="ib-menu-link" id="ib-community-nav">IB in the Community</a>
                                <a href="#ib-location" class="ib-menu-link" id="ib-location-nav">IB Locations</a>
                            </div>
                        </div>
                    </div>
                <?php
            } else if(strpos($_SERVER['REQUEST_URI'], 'resources') !== false || strpos($_SERVER['REQUEST_URI'], 'blog') !== false || strpos($_SERVER['REQUEST_URI'], 'category') !== false || strpos($_SERVER['REQUEST_URI'], 'online-forms') !== false || strpos($_SERVER['REQUEST_URI'], 'media-gallery') !== false) {
                ?>
                    <style>
                        a.ib-menu-link.ib-resources {
                            background-color: #98A544;
                            color: #FFF;
                        }
                    </style>

                    <!-- sub header start -->
                    <div class="ib-sub-header">
                        <div class="ib-sub-header-wrap">
                            <div class="ib-navigation">
                                <a href="/resources" class="ib-menu-link">Announcement</a>
                                <a href="/online-forms" class="ib-menu-link">Online Application Forms</a>
                                <a href="/media-gallery" class="ib-menu-link">Media & Gallery</a>
                                <a href="/blog" class="ib-menu-link">Blog</a>
                            </div>
                        </div>
                    </div>
                <?php
            }
        ?>
    </header>
    <!-- #site-header -->